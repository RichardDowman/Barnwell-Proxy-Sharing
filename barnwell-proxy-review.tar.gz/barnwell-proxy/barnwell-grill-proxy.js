#!/usr/bin/env node
/**
 * Barnwell Grill Proxy — Stable endpoints + Webhook + Goodcom print
 *
 * Restored endpoints (do NOT rename):
 * - GET  /api/health
 * - GET  /api/settings
 * - GET  /api/admin/settings           (header X-Admin-Token)
 * - PUT  /api/admin/settings           (header X-Admin-Token)
 * - GET  /api/zonesPublic
 * - POST /api/delivery-price           (body: {postcode} or {lat,lng})
 * - GET  /api/catalogEverything?types=ITEM,ITEM_VARIATION,CATEGORY,MODIFIER_LIST,ITEM_OPTION
 * - POST /api/create-checkout-link     (returns payment link + printable_receipt + order_ref)
 *
 * Additional endpoints kept:
 * - GET  /api/geocode?postcode=PE84QU  (Google if key present, else postcodes.io; returns Google-like JSON)
 * - POST /api/square-webhook           (verifies optional signature; matches order; enqueues print job on completion)
 * - GET  /api/printer-feed.txt         (Goodcom pulls next ticket; token required if PRINTER_TOKEN set)
 * - POST /api/admin/print-test         (X-Admin-Token; enqueues a test ticket)
 * - POST /api/printer-callback         (optional; logs callback)
 *
 * ENV (/etc/barnwell-proxy.env):
 *   PORT=8080
 *   DATA_DIR=/var/www/barnwell-proxy/data
 *   ADMIN_TOKEN=REDACTED
 *   CORS_ORIGINS=https://barnwellgrill.gbapps.cmslogin.io
 *   SQUARE_ENV=production|sandbox
 *   SQUARE_ACCESS_TOKEN=REDACTED
 *   SQUARE_LOCATION_ID=...
 *   CHECKOUT_RETURN_URL=https://barnwellgrill.gbapps.cmslogin.io/ordering?paid=1
 *   SQUARE_WEBHOOK_SIGNATURE_KEY=...      (optional; if set, signature is verified)
 *   GOOGLE_MAPS_API_KEY=REDACTED               (optional; else fallback to postcodes.io)
 *   PRINTER_TOKEN=REDACTED      (optional; if set, printer must include ?token=REDACTED
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');

/* ---------- ENV loader ---------- */
(function loadEnvFile() {
  try {
    const p = '/etc/barnwell-proxy.env';
    if (fs.existsSync(p)) {
      const txt = fs.readFileSync(p, 'utf8');
      for (const line of txt.split(/\r?\n/)) {
        const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
        if (!m) continue;
        const k = m[1]; let v = m[2];
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
        if (!(k in process.env)) process.env[k] = v;
      }
    }
  } catch (_) {}
})();

/* ---------- CONFIG ---------- */
const PORT = parseInt(process.env.PORT || '8080', 10);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const ORDERS_DIR = path.join(DATA_DIR, 'orders');
const PRINTER_DIR = path.join(DATA_DIR, 'printer');
const QUEUE_DIR = path.join(PRINTER_DIR, 'queue');
const DONE_DIR = path.join(PRINTER_DIR, 'done');

const ADMIN_TOKEN = (process.env.ADMIN_TOKEN || '').trim();
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY || '';
const CORS_ORIGINS = (process.env.CORS_ORIGINS || 'https://barnwellgrill.gbapps.cmslogin.io').split(',').map(s => s.trim()).filter(Boolean);

const SQUARE_ENV = (process.env.SQUARE_ENV || 'production').toLowerCase();
const SQUARE_BASE = SQUARE_ENV === 'sandbox' ? 'https://connect.squareupsandbox.com' : 'https://connect.squareup.com';
const SQUARE_ACCESS_TOKEN = process.env.SQUARE_ACCESS_TOKEN || '';
const SQUARE_LOCATION_ID = process.env.SQUARE_LOCATION_ID || '';
const CHECKOUT_RETURN_URL = process.env.CHECKOUT_RETURN_URL || 'https://barnwellgrill.gbapps.cmslogin.io/ordering?paid=1';
const SQUARE_WEBHOOK_SIGNATURE_KEY = process.env.SQUARE_WEBHOOK_SIGNATURE_KEY || '';
const PRINTER_TOKEN = (process.env.PRINTER_TOKEN || '').trim();

/* ---------- FS bootstrap ---------- */
for (const d of [DATA_DIR, ORDERS_DIR, PRINTER_DIR, QUEUE_DIR, DONE_DIR]) {
  try { fs.mkdirSync(d, { recursive: true }); } catch (_) {}
}

/* ---------- Helpers ---------- */
const fetch = global.fetch || ((...a) => Promise.reject(new Error('fetch not available')));
const readJSON = (f, fb = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fb; } };
const writeJSON = (f, o) => fs.writeFileSync(f, JSON.stringify(o, null, 2));
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const money = (p) => '£' + (Number(p || 0) / 100).toFixed(2);
const nowISO = () => new Date().toISOString();

function setCors(req, res) {
  const origin = req.headers.origin || '';
  if (!origin) { res.setHeader('Access-Control-Allow-Origin', '*'); return; }
  if (CORS_ORIGINS.includes(origin)) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
  else { res.setHeader('Access-Control-Allow-Origin', CORS_ORIGINS[0] || '*'); res.setHeader('Vary', 'Origin'); }
}
function cors(req, res, next) {
  setCors(req, res);
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Token, ngrok-skip-browser-warning, x-square-signature, x-square-hmacsha256-signature');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
}
function normalizePhoneUK(phone) {
  if (!phone) return '';
  let s = String(phone).replace(/[().\-\s]/g, '');
  if (s.startsWith('00')) s = '+' + s.slice(2);
  if (/^0\d{9,10}$/.test(s)) s = '+44' + s.slice(1);
  if (/^\d{10,11}$/.test(s)) s = '+44' + s;
  if (/^\+\d{7,15}$/.test(s)) return s;
  const d = s.replace(/\D/g, '');
  if (/^\d{10,11}$/.test(d)) return '+44' + d;
  if (/^\d{7,15}$/.test(d)) return '+' + d;
  return '';
}
function splitName(full) {
  if (!full) return { given_name: '', family_name: '' };
  const parts = String(full).trim().split(/\s+/);
  return parts.length === 1 ? { given_name: parts[0], family_name: '' } : { given_name: parts[0], family_name: parts.slice(1).join(' ') };
}
function pointInRing(lng, lat, ring) {
  if (!Array.isArray(ring) || ring.length < 3) return false;
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = Number(ring[i][0]), yi = Number(ring[i][1]);
    const xj = Number(ring[j][0]), yj = Number(ring[j][1]);
    const intersect = ((yi > lat) !== (yj > lat)) && (lng < (xj - xi) * (lat - yi) / ((yj - yi) || 1e-12) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}
/* Geocode helpers */
async function geocodeWithGoogle(addr) {
  const url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURIComponent(addr) + '&key=' + encodeURIComponent(GOOGLE_MAPS_API_KEY);
  const r = await fetch(url); return await r.json().catch(() => null);
}
async function geocodeWithPostcodesIo(pc) {
  try { const r = await fetch('https://api.postcodes.io/postcodes/' + encodeURIComponent(pc)); return await r.json().catch(() => null); }
  catch (_) { return null; }
}
/* Receipt builder (63 cols) */
function buildReceipt(payload) {
  const width = 63, dash = '-'.repeat(width);
  const items = Array.isArray(payload.items) ? payload.items : [];
  const fee = clamp(Number(payload.delivery_fee_pence || 0), 0, 10_000_000);
  const meta = payload.meta || {}, customer = meta.customer || {};
  const fulfil = (meta.fulfilment || 'collection').toLowerCase();
  const sch = meta.scheduled_at ? new Date(meta.scheduled_at) : null;
  let dateStr = 'ASAP';
  if (sch && !isNaN(sch)) {
    const d = sch.getDate(), m = sch.toLocaleString('default', { month: 'short' });
    const hh = String(sch.getHours()).padStart(2, '0'), mm = String(sch.getMinutes()).padStart(2, '0');
    let ord = 'th'; if (![11, 12, 13].includes(d % 100)) { if (d % 10 === 1) ord = 'st'; else if (d % 10 === 2) ord = 'nd'; else if (d % 10 === 3) ord = 'rd'; }
    dateStr = `${d}${ord} ${m} @ ${hh}:${mm}`;
  }
  const lines = [];
  lines.push('                             ORDER');
  lines.push(`ORDER TYPE = ${fulfil.toUpperCase()}`);
  lines.push(`ORDER DATE = ${dateStr}`);
  lines.push('');
  lines.push(`Name: ${customer.name || ''}`);
  lines.push(`Phone: ${customer.phone || ''}`);
  if (fulfil === 'delivery' && meta.address) lines.push(`Address: ${meta.address}`);
  lines.push('');
  lines.push(dash);
  for (const it of items) {
    const qty = Number(it.quantity || 1) || 1;
    const unit = Number(it.unit_pence || 0) || 0;
    const total = qty * unit;
    const name = String(it.name || 'Item');
    const title = qty > 1 ? `${name} (+${qty - 1})` : name;
    const price = money(total);
    const left = width - price.length;
    lines.push((title.length > left ? title.slice(0, left) : title).padEnd(left, ' ') + price);
    if (Array.isArray(it.groups)) {
      for (const g of it.groups) {
        if (!g || !g.name) continue;
        const vals = Array.isArray(g.values) ? g.values.filter(Boolean) : [];
        if (!vals.length) continue;
        lines.push(`${g.name}: ${vals.join(', ')}`);
      }
    }
    lines.push(dash);
  }
  const subtotal = items.reduce((s, it) => s + (Number(it.unit_pence || 0) * (Number(it.quantity || 1) || 1)), 0);
  const total = subtotal + fee;
  const tot = (label, amt) => {
    const lbl = label.toUpperCase() + ':';
    const amtTxt = money(amt);
    const space = width - lbl.length - amtTxt.length;
    return lbl + (space > 0 ? ' '.repeat(space) : ' ') + amtTxt;
  };
  lines.push(tot('SUBTOTAL', subtotal));
  lines.push(tot('DELIVERY FEE', fee));
  lines.push(tot('TOTAL', total));
  lines.push('');
  return lines.join('\n');
}

/* ---------- EXPRESS ---------- */
const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(cors);

/* ---------- Settings & zones storage ---------- */
const settingsFile = path.join(DATA_DIR, 'settings.json');
const zonesFile = path.join(DATA_DIR, 'zones.json');
if (!fs.existsSync(settingsFile)) writeJSON(settingsFile, {});
if (!fs.existsSync(zonesFile)) writeJSON(zonesFile, { zones: [] });

/* ---------- Core (restored) endpoints ---------- */
app.get('/api/health', (req, res) => { setCors(req, res); res.json({ ok: true, env: SQUARE_ENV }); });

app.get('/api/settings', (req, res) => {
  setCors(req, res);
  const j = readJSON(settingsFile, {});
  res.json({
    businessHours: j.businessHours || {},
    slotConfig: j.slotConfig || {},
    manualClose: j.manualClose || { closed: false, reopenAt: null },
    manualClosed: !!(j.manualClose && j.manualClose.closed),
    reopenAt: j.manualClose ? j.manualClose.reopenAt : null,
    weekly: j.weekly || undefined
  });
});

function checkAdmin(req, res) {
  if (!ADMIN_TOKEN) { res.status(500).json({ error: 'admin_token_not_configured' }); return false; }
  if ((req.headers['x-admin-token'] || '').trim() !== ADMIN_TOKEN) { res.status(401).json({ error: 'unauthorized' }); return false; }
  return true;
}
app.get('/api/admin/settings', (req, res) => { setCors(req, res); if (!checkAdmin(req, res)) return; res.json(readJSON(settingsFile, {})); });
app.put('/api/admin/settings', (req, res) => {
  setCors(req, res); if (!checkAdmin(req, res)) return;
  const cur = readJSON(settingsFile, {}); const merged = Object.assign({}, cur, req.body || {});
  writeJSON(settingsFile, merged); res.json({ ok: true, saved: true });
});

app.get('/api/zonesPublic', (req, res) => { setCors(req, res); res.json({ zones: (readJSON(zonesFile, { zones: [] })).zones || [] }); });
app.get('/api/zones', (req, res) => { setCors(req, res); res.json({ zones: (readJSON(zonesFile, { zones: [] })).zones || [] }); });

/* Geocode — fixes your 404 and returns Google-like JSON */
app.get('/api/geocode', async (req, res) => {
  try {
    setCors(req, res);
    const pc = (req.query.postcode || req.query.address || '').trim();
    if (!pc) return res.status(400).json({ results: [], status: 'ZERO_RESULTS', error: 'no_postcode' });

    if (GOOGLE_MAPS_API_KEY) {
      const j = await geocodeWithGoogle(pc + ', UK');
      return res.json(j || { results: [], status: 'ZERO_RESULTS' });
    }
    const pj = await geocodeWithPostcodesIo(pc);
    if (!pj || !pj.result) return res.json({ results: [], status: 'ZERO_RESULTS' });
    const p = pj.result;
    const formatted = [
      p.admin_ward || '',
      p.parliamentary_constituency || '',
      p.postcode || '',
      p.region || '',
      p.country || ''
    ].filter(Boolean).join(', ') || p.postcode || pc;
    return res.json({
      results: [{ formatted_address: formatted, geometry: { location: { lat: p.latitude, lng: p.longitude } }, postcode: p.postcode }],
      status: 'OK'
    });
  } catch (e) {
    return res.status(500).json({ results: [], status: 'ERROR', error: String(e && e.message || e) });
  }
});

/* Delivery price — matches {lat,lng} or {postcode} against polygon zones */
app.post('/api/delivery-price', async (req, res) => {
  try {
    setCors(req, res);
    const body = req.body || {};
    let { lat, lng, postcode } = body;
    let L = (typeof lat === 'number') ? lat : null;
    let G = (typeof lng === 'number') ? lng : null;

    if ((L == null || G == null) && postcode) {
      if (GOOGLE_MAPS_API_KEY) {
        const j = await geocodeWithGoogle(postcode + ', UK').catch(() => null);
        const loc = j?.results?.[0]?.geometry?.location;
        if (loc) { L = Number(loc.lat); G = Number(loc.lng); }
      } else {
        const pj = await geocodeWithPostcodesIo(postcode).catch(() => null);
        if (pj && pj.result) { L = Number(pj.result.latitude); G = Number(pj.result.longitude); }
      }
    }

    const settings = readJSON(settingsFile, {});
    const minOrder = settings?.slotConfig?.delivery?.min_order_pence ?? 1200;

    if (L == null || G == null) {
      return res.json({ deliverable: false, reason: 'no_location', min_order_pence: minOrder });
    }

    const zones = (readJSON(zonesFile, { zones: [] }).zones || []);
    let hit = null;
    for (const z of zones) {
      if (z.active === false) continue;
      const ring = (z.polygon?.coordinates?.[0]) || z.ring || z.coordinates || null;
      if (!Array.isArray(ring) || ring.length < 3) continue;
      const ringNum = ring.map(pt => [Number(pt[0]), Number(pt[1])]);
      if (pointInRing(G, L, ringNum)) { hit = z; break; }
    }

    if (!hit) return res.json({ deliverable: false, matched: false, min_order_pence: minOrder });

    const pence = Number(hit.price_pence != null ? hit.price_pence : Math.round((hit.price || 0) * 100));
    return res.json({ deliverable: true, matched: true, zoneName: hit.name || hit.id || 'Zone', price_pence: pence, min_order_pence: minOrder });
  } catch (e) {
    return res.status(500).json({ error: 'quote_failed', detail: String(e && e.message || e) });
  }
});

/* Catalog passthrough — no rename */
app.get('/api/catalogEverything', async (req, res) => {
  try {
    setCors(req, res);
    if (!SQUARE_ACCESS_TOKEN) return res.status(500).json({ error: 'no_square_token' });
    const types = String(req.query.types || 'ITEM,ITEM_VARIATION,CATEGORY,MODIFIER_LIST,ITEM_OPTION')
      .split(',').map(s => s.trim()).filter(Boolean);
    const body = { object_types: types, include_related_objects: true };
    const r = await fetch(`${SQUARE_BASE}/v2/catalog/search`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${SQUARE_ACCESS_TOKEN}`, 'Square-Version': '2024-08-15', 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const j = await r.json().catch(() => null);
    if (!r.ok) return res.status(500).json({ error: 'square_catalog_error', status: r.status, detail: j });
    res.json({ objects: j.objects || [], related_objects: j.related_objects || [] });
  } catch (e) {
    res.status(500).json({ error: 'catalog_failed', detail: String(e) });
  }
});

/* Create checkout link — stores order for webhook, safe prefill, fallback when meta causes Square errors */
app.post('/api/create-checkout-link', async (req, res) => {
  try {
    setCors(req, res);
    const payload = req.body || {};
    const items = Array.isArray(payload.items) ? payload.items : [];
    const fee = clamp(Number(payload.delivery_fee_pence || 0), 0, 10_000_000);
    const subtotal = items.reduce((s, it) => s + (Number(it.unit_pence || 0) * (Number(it.quantity || 1) || 1)), 0);
    const total = subtotal + fee;

    if (!SQUARE_ACCESS_TOKEN || !SQUARE_LOCATION_ID) return res.status(500).json({ ok: false, error: 'square_config_missing' });
    if (!total || total <= 0) return res.status(400).json({ ok: false, error: 'invalid_total' });

    const printable_receipt = buildReceipt(Object.assign({}, payload, { delivery_fee_pence: fee }));

    const pre = {};
    const c = (payload.meta && payload.meta.customer) || {};
    if (c.phone) { const n = normalizePhoneUK(c.phone); if (/^\+\d{7,15}$/.test(n)) pre.buyer_phone_number = n; }
    if (c.email && String(c.email).includes('@')) pre.buyer_email = c.email;
    if (c.name) { const n = splitName(c.name); if (n.given_name) pre.buyer_given_name = n.given_name; if (n.family_name) pre.buyer_family_name = n.family_name; }

    const orderRef = crypto.randomUUID();
    let returnUrl = CHECKOUT_RETURN_URL || '';
    if (returnUrl) returnUrl += (returnUrl.includes('?') ? '&' : '?') + 'paid=1&ref=' + orderRef;

    const body = {
      idempotency_key: orderRef,
      quick_pay: { location_id: SQUARE_LOCATION_ID, name: (payload.title || 'Barnwell Grill Order'),
        price_money: { amount: total, currency: String(payload.currency || 'GBP').toUpperCase() } },
      pre_populated_data: Object.keys(pre).length ? pre : undefined,
      checkout_options: returnUrl ? { redirect_url: returnUrl } : undefined
    };

    async function createLink(b) {
      const r = await fetch(`${SQUARE_BASE}/v2/online-checkout/payment-links`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${SQUARE_ACCESS_TOKEN}`, 'Square-Version': '2024-08-15', 'Content-Type': 'application/json' },
        body: JSON.stringify(b)
      });
      const j = await r.json().catch(() => null);
      return { r, j };
    }

    let { r, j } = await createLink(body);
    if (!r.ok && body.pre_populated_data) {
      const fallback = Object.assign({}, body); delete fallback.pre_populated_data;
      ({ r, j } = await createLink(fallback));
    }
    if (!r.ok) return res.status(502).json({ ok: false, error: 'square_payment_link_failed', status: r.status, detail: j });

    const url = j?.payment_link?.url || j?.url || null;
    const paymentLinkId = j?.payment_link?.id || null;
    res.json({ ok: true, method: 'square.payment-links', url, printable_receipt, order_ref: orderRef, payment_link_id: paymentLinkId });

    // Persist order for webhook matching
    try {
      writeJSON(path.join(ORDERS_DIR, orderRef + '.json'), {
        order_ref: orderRef, created_at: nowISO(), payload, printable_receipt,
        payment_link_id: paymentLinkId, payment_link_url: url,
        total_pence: total, sentToPrinter: false
      });
    } catch (_) {}
  } catch (e) {
    res.status(500).json({ ok: false, error: 'create_checkout_failed', detail: String(e) });
  }
});

/* ---------- Goodcom printer queue ---------- */
function listTxt(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => f.endsWith('.txt'))
      .map(f => ({ f, p: path.join(dir, f), m: fs.statSync(path.join(dir, f)).mtimeMs }))
      .sort((a, b) => a.m - b.m);
  } catch { return []; }
}
function enqueueTicket(text, meta = {}) {
  const id = Date.now() + '-' + (meta.order_ref || crypto.randomUUID());
  const body = (text || '').replace(/\r?\n/g, '\r\n'); // CRLF for Goodcom
  const txtFile = path.join(QUEUE_DIR, id + '.txt');
  const jsonFile = path.join(QUEUE_DIR, id + '.json');
  fs.writeFileSync(txtFile, body);
  fs.writeFileSync(jsonFile, JSON.stringify({ id, meta, enqueued_at: nowISO() }, null, 2));
  return id;
}

/* Single, token-checked feed endpoint (no duplicates) */
app.get('/api/printer-feed.txt', (req, res) => {
  if (PRINTER_TOKEN && req.query.token !== PRINTER_TOKEN) {
    return res.status(401).type('text').send('unauthorized');
  }
  const jobs = listTxt(QUEUE_DIR);
  if (!jobs.length) return res.status(204).end(); // no job now
  const job = jobs[0];
  const body = fs.readFileSync(job.p, 'utf8');

  // Move to done (unless peek=1)
  const peek = String(req.query.peek || '') === '1';
  if (!peek) {
    try { fs.renameSync(job.p, path.join(DONE_DIR, path.basename(job.p))); } catch (_) {}
    const twin = job.p.replace(/\.txt$/, '.json');
    try { if (fs.existsSync(twin)) fs.renameSync(twin, path.join(DONE_DIR, path.basename(twin))); } catch (_) {}
  }

  res.setHeader('Cache-Control', 'no-store');
  res.type('text/plain').send(body);
});

app.post('/api/printer-callback', express.text({ type: '*/*' }), (req, res) => {
  const info = { when: nowISO(), ip: (req.headers['x-forwarded-for'] || req.ip), body: (req.body || '').slice(0, 500) };
  try { fs.writeFileSync(path.join(PRINTER_DIR, 'last-callback.json'), JSON.stringify(info, null, 2)); } catch (_) {}
  res.json({ ok: true });
});

app.post('/api/admin/print-test', (req, res) => {
  setCors(req, res); if (!checkAdmin(req, res)) return;
  const text = (req.body && req.body.text) || [
    'TEST PRINT',
    '',
    'This is a test ticket from Barnwell proxy.',
    '-------------------------------',
    'Time: ' + nowISO(),
    ''
  ].join('\n');
  const id = enqueueTicket(text, { source: 'admin-test' });
  res.json({ ok: true, enqueued: id });
});

/* ---------- Square webhook -> enqueue print on completed ---------- */
app.post('/api/square-webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    // optional signature verification
    if (SQUARE_WEBHOOK_SIGNATURE_KEY) {
      const hA = String(req.headers['x-square-signature'] || '');
      const hB = String(req.headers['x-square-hmacsha256-signature'] || '');
      const calc = crypto.createHmac('sha256', SQUARE_WEBHOOK_SIGNATURE_KEY).update(req.body).digest('base64');
      if ((hA && hA !== calc) && (hB && hB !== calc)) return res.status(401).send('signature_mismatch');
      if (!hA && !hB) return res.status(401).send('signature_required');
    }

    const evt = JSON.parse(req.body.toString('utf8'));
    const type = evt?.type || evt?.event_type || '';
    const payment = evt?.data?.object?.payment || null;

    // match order by payment_link_id
    let order = null;
    if (payment?.payment_link_id) {
      const files = fs.readdirSync(ORDERS_DIR).filter(f => f.endsWith('.json'));
      for (const f of files) {
        const o = readJSON(path.join(ORDERS_DIR, f), null);
        if (o && o.payment_link_id === payment.payment_link_id) { order = o; break; }
      }
    }
    // fallback: reference keys
    if (!order) {
      const ref = payment?.reference_id || payment?.order_id || payment?.note;
      if (ref && fs.existsSync(path.join(ORDERS_DIR, ref + '.json'))) order = readJSON(path.join(ORDERS_DIR, ref + '.json'), null);
    }

    if (!order) {
      // store unmatched for inspection
      try { fs.writeFileSync(path.join(ORDERS_DIR, 'unmatched-' + Date.now() + '.json'), JSON.stringify(evt, null, 2)); } catch (_) {}
      return res.json({ ok: true, matched: false });
    }

    const status = payment?.status || '';
    const completed = /COMPLETED|PAID|CAPTURED/i.test(status) || /payment\.created/i.test(type);

    // update order with payment info
    order.payment = { id: payment?.id || null, status, raw: payment };
    writeJSON(path.join(ORDERS_DIR, order.order_ref + '.json'), order);

    if (completed && !order.sentToPrinter) {
      enqueueTicket(order.printable_receipt || 'ORDER\n(no receipt text)\n', { order_ref: order.order_ref, payment_id: payment?.id || null });
      order.sentToPrinter = true;
      writeJSON(path.join(ORDERS_DIR, order.order_ref + '.json'), order);
      return res.json({ ok: true, printedQueued: true });
    }
    return res.json({ ok: true, matched: true, completed, status, alreadyQueued: !!order.sentToPrinter });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e && e.message || e) });
  }
});

/* ---------- START ---------- */
app.listen(PORT, () => {
  console.log('barnwell-proxy (stable endpoints + webhook + goodcom) listening on :' + PORT);
});
